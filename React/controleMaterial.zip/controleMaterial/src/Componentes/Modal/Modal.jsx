import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Modal from '@mui/material/Modal';
import EditNoteIcon from '@mui/icons-material/EditNote';
import { TextField } from '@mui/material';
import Typography from '@mui/material/Typography';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  borderRadius: '10px',
  p: 4,
};

export default function BasicModal() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button onClick={handleOpen}>
            <EditNoteIcon sx={{ fontSize: 30 }}/>
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        
        <Box
      component="form"
      sx={{
        // '& .MuiTextField-root': { m: 1 },
        // alignContent: "center",
        // alignItems: "center",
        // width: "50%",
        // display: "grid",
        // backgroundColor: "#D8F0CC",
        // margin: "10 px",
        // padding: "10px"
      }}
      noValidate
      autoComplete="off"
    >
        <div>
            <TextField
            id="outlined-multiline-flexible"
            label="Produto"
            multiline
            maxRows={4}
            
            />
        </div>

        <div>
            <TextField
            id="outlined-multiline-flexible"
            label="Quantidade"
            multiline
            maxRows={4}
           
            />
        </div>

        <div>
            <TextField
            id="outlined-multiline-flexible"
            label="Preço R$"
            multiline
            maxRows={4}
           
            />
        </div>

        <div>
            {/* <Button label="Success" severity="success" raised /> */}
            <Button variant="contained" color="success" onClick={()=>{
                if(nome !== ''){
                axios({
                    method: "post",
                    url: "http://localhost:3000/material/cadastrar/",
                    data: {
                    nome: nome,
                    quantidade: quantidade,
                    preco: preco
                        },
                      })
                      .then(()=>{
                        console.log("Material cadastrado!")
                        if(controle==false){
                            props.salvou (true)
                            setControle(true)
                        }
                        else{
                            props.salvou(false)
                            setControle(false)
                        }
                      })
                }
            }}>Salvar</Button>
        </div>

    </Box>

      </Modal>
    </div>
  );
}