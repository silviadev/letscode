// ! limpo o local storage
localStorage.clear();

// ! pegar um item do localStorage passando a key
localStorage.getItem("key");

// ! pegar a key através de um indice
localStorage.key(index);

// ! setar/adicionar um item no localStorage
localStorage.setItem("key", "valor");

// ! quantidade de key que temos no localStorage
localStorage.length;

// ! deleta o item correspondente a key
localStorage.removeItem("key");